import scrapy
from site_search_poc.items import SiteSearchPocItem
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

class PocCrawlSpider(CrawlSpider):
    name = "poc-crawl"
    allowed_domains = ["pulsar.apache.org", "scrapingclub.com", "en.wikipedia.org"]
    le1 = LinkExtractor(allow=r'')
    rules = [
        Rule(le1, callback='parse'),
    ]
    # urls = ["https://pulsar.apache.org/", "https://scrapingclub.com/exercise/list_infinite_scroll/"]
    urls = ["https://en.wikipedia.org/wiki/Web_scraping"]
    domain_name = urls[0].split("/")[2]
    custom_settings = {
        'DEPTH_LIMIT': 1,  # Set the desired depth limit
    }
    def start_requests(self):
        for url in self.urls:
            yield scrapy.Request(url, meta={
                    "playwright": True,
                    "playwright_context_kwargs": {
                        "ignore_https_errors": True,
                    },
                })

    def parse(self, response):
        context = SiteSearchPocItem()
        context['url'] = response.url
        context['title'] = response.css("title::text").get()
        context['metaDescription'] = response.xpath('//meta[@name="description"]/@content').extract_first()
        paragraphs = []
        text_tags = ['p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'li', 'ol', 'ul']
        for tag in text_tags:
            for selector in response.css(tag):
                text = selector.xpath('string(.)').get().strip().replace("\n", "")
                if len(text) !=0 :
                    paragraphs.append(text)
        context['paragraphs'] = paragraphs
        yield context
        links = self.le1.extract_links(response)
        for link in links:
            yield scrapy.Request(link.url, callback=self.parse)