# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html

# useful for handling different item types with a single interface
import json
import time
import os
from itemadapter import ItemAdapter


class SiteSearchPocPipeline:
    def open_spider(self, spider):
        pass

    def close_spider(self, spider):
        pass

    def process_item(self, item, spider):
        yyyy = time.strftime("%Y")
        mm = time.strftime("%m")
        dd = time.strftime("%d")
        url = item['url'].split("/")[2]
        path = f"./{yyyy}/{mm}/{dd}/{url}"
        if not os.path.exists(path):
            os.makedirs(path)
        num = 1
        while os.path.isfile(f"./{yyyy}/{mm}/{dd}/{url}/item{num}.json"):
            num += 1
        self.file = open(f"./{yyyy}/{mm}/{dd}/{url}/item{num}.json", "w")
        line = json.dumps(ItemAdapter(item).asdict()) + "\n"
        self.file.write(line)
        self.file.close()
        return item
