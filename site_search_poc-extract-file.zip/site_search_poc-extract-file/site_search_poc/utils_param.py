import time

def uri_params(params, spider):      
    return {**params, 
            "spider_name": spider.name,
            "now_year": time.strftime("%Y"), 
            "now_month": time.strftime("%m"), 
            "now_date": time.strftime("%d")}